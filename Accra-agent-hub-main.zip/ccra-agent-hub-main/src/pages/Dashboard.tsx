import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Navigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Home, FileText, Clock, CheckCircle, XCircle, Building2, LogOut } from 'lucide-react';
import { PropertyForm } from '@/components/PropertyForm';
import { PropertyList } from '@/components/PropertyList';
import { AdminPanel } from '@/components/AdminPanel';

export default function Dashboard() {
  const { user, userRole, profile, loading, signOut } = useAuth();
  const [properties, setProperties] = useState<any[]>([]);
  const [showPropertyForm, setShowPropertyForm] = useState(false);
  const [loadingProperties, setLoadingProperties] = useState(true);

  // Redirect if not authenticated
  if (!loading && !user) {
    return <Navigate to="/auth" replace />;
  }

  useEffect(() => {
    if (user && userRole === 'landlord') {
      fetchProperties();
    }
  }, [user, userRole]);

  const fetchProperties = async () => {
    try {
      const { data, error } = await supabase
        .from('properties')
        .select(`
          *,
          property_images (*)
        `)
        .eq('landlord_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProperties(data || []);
    } catch (error) {
      console.error('Error fetching properties:', error);
    } finally {
      setLoadingProperties(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-success text-success-foreground"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge className="bg-pending text-pending-foreground"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    }
  };

  const getVerificationStatus = () => {
    if (!profile) return null;
    
    switch (profile.ghana_card_status) {
      case 'approved':
        return <Badge className="bg-success text-success-foreground">Verified</Badge>;
      case 'rejected':
        return <Badge variant="destructive">Rejected</Badge>;
      default:
        return <Badge className="bg-pending text-pending-foreground">Pending Verification</Badge>;
    }
  };

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // Admin Dashboard
  if (userRole === 'admin') {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <div className="flex items-center space-x-4">
                <Building2 className="h-8 w-8 text-primary" />
                <h1 className="text-xl font-semibold">E-agent Admin</h1>
              </div>
              <Button variant="outline" onClick={signOut}>
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </header>
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <AdminPanel />
        </main>
      </div>
    );
  }

  // Landlord Dashboard
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Building2 className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-xl font-semibold">E-agent</h1>
                <p className="text-sm text-muted-foreground">Welcome, {profile?.full_name}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {getVerificationStatus()}
              <Button variant="outline" onClick={signOut}>
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {profile?.ghana_card_status !== 'approved' ? (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-pending" />
                Account Verification Required
              </CardTitle>
              <CardDescription>
                Your Ghana Card is being reviewed by our admin team. You can start adding property details, 
                but properties won't be published until your account is verified.
              </CardDescription>
            </CardHeader>
            {profile?.verification_notes && (
              <CardContent>
                <div className="p-4 bg-muted rounded-lg">
                  <p className="text-sm"><strong>Admin Notes:</strong> {profile.verification_notes}</p>
                </div>
              </CardContent>
            )}
          </Card>
        ) : null}

        <Tabs defaultValue="properties" className="space-y-6">
          <TabsList>
            <TabsTrigger value="properties" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              My Properties ({properties.length})
            </TabsTrigger>
            <TabsTrigger value="add-property" className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Property
            </TabsTrigger>
          </TabsList>

          <TabsContent value="properties">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">My Properties</h2>
                <Button onClick={() => setShowPropertyForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Property
                </Button>
              </div>

              {loadingProperties ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full"></div>
                </div>
              ) : (
                <PropertyList 
                  properties={properties} 
                  onUpdate={fetchProperties}
                  showStatus={true}
                />
              )}
            </div>
          </TabsContent>

          <TabsContent value="add-property">
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Add New Property</h2>
              <PropertyForm 
                onSuccess={() => {
                  fetchProperties();
                  setShowPropertyForm(false);
                }} 
              />
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {showPropertyForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-background rounded-lg max-w-2xl w-full max-h-[90vh] overflow-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">Add New Property</h3>
                <Button variant="ghost" onClick={() => setShowPropertyForm(false)}>
                  ×
                </Button>
              </div>
              <PropertyForm onSuccess={() => {
                fetchProperties();
                setShowPropertyForm(false);
              }} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}