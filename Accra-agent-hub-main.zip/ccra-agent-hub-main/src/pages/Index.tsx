// Update this page (the content is just a fallback if you fail to update the page)

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/10">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-lg">E</span>
                </div>
                <span className="text-xl font-bold">E-agent</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <a
                href="/auth"
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                Sign In
              </a>
              <a
                href="/auth"
                className="bg-primary text-primary-foreground px-4 py-2 rounded-md hover:bg-primary/90 transition-colors"
              >
                Get Started
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-20 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-foreground mb-6">
            Your Property,
            <span className="text-primary"> Verified & Listed</span>
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            E-agent connects verified landlords in Accra with our rental mobile app. 
            Get your properties reviewed, approved, and published to reach quality tenants.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="/auth"
              className="bg-primary text-primary-foreground px-8 py-3 rounded-lg text-lg font-semibold hover:bg-primary/90 transition-colors"
            >
              List Your Property
            </a>
            <a
              href="#how-it-works"
              className="border border-border text-foreground px-8 py-3 rounded-lg text-lg font-semibold hover:bg-accent transition-colors"
            >
              Learn More
            </a>
          </div>
        </div>

        {/* Features Section */}
        <section id="how-it-works" className="py-20">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              How It Works
            </h2>
            <p className="text-xl text-muted-foreground">
              Simple steps to get your properties verified and listed
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-primary">1</span>
              </div>
              <h3 className="text-xl font-semibold">Register & Verify</h3>
              <p className="text-muted-foreground">
                Sign up with your details and upload your Ghana Card for verification. 
                Our admin team reviews within 24-48 hours.
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-primary">2</span>
              </div>
              <h3 className="text-xl font-semibold">Upload Properties</h3>
              <p className="text-muted-foreground">
                Add your property details, photos, and required documents. 
                Include tenancy agreements and ownership papers.
              </p>
            </div>

            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-primary">3</span>
              </div>
              <h3 className="text-xl font-semibold">Get Approved</h3>
              <p className="text-muted-foreground">
                Once approved, your properties automatically appear on our rental mobile app, 
                connecting you with verified tenants.
              </p>
            </div>
          </div>
        </section>

        {/* Benefits Section */}
        <section className="py-20 bg-card/50 rounded-2xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Why Choose E-agent?
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto">
                <span className="text-success text-xl">✓</span>
              </div>
              <h4 className="font-semibold">Verified Landlords</h4>
              <p className="text-sm text-muted-foreground">Ghana Card verification ensures authenticity</p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto">
                <span className="text-success text-xl">✓</span>
              </div>
              <h4 className="font-semibold">Quality Control</h4>
              <p className="text-sm text-muted-foreground">Admin review ensures property quality</p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto">
                <span className="text-success text-xl">✓</span>
              </div>
              <h4 className="font-semibold">Wide Reach</h4>
              <p className="text-sm text-muted-foreground">Access to our mobile app user base</p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center mx-auto">
                <span className="text-success text-xl">✓</span>
              </div>
              <h4 className="font-semibold">Secure Platform</h4>
              <p className="text-sm text-muted-foreground">Document verification and secure storage</p>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Ready to List Your Properties?
          </h2>
          <p className="text-xl text-muted-foreground mb-8">
            Join verified landlords on E-agent today
          </p>
          <a
            href="/auth"
            className="bg-primary text-primary-foreground px-8 py-4 rounded-lg text-lg font-semibold hover:bg-primary/90 transition-colors inline-block"
          >
            Get Started Now
          </a>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-muted-foreground">
            <p>&copy; 2024 E-agent. All rights reserved. | Property Management Platform for Accra</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
