import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Clock, MapPin, DollarSign, Edit, Eye } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useState, useEffect } from 'react';

interface PropertyListProps {
  properties: any[];
  onUpdate?: () => void;
  showStatus?: boolean;
  isAdmin?: boolean;
  onApprove?: (propertyId: string, notes?: string) => void;
  onReject?: (propertyId: string, notes: string) => void;
}

export function PropertyList({ 
  properties, 
  onUpdate, 
  showStatus = false, 
  isAdmin = false,
  onApprove,
  onReject 
}: PropertyListProps) {
  const [imageUrls, setImageUrls] = useState<Record<string, string>>({});

  useEffect(() => {
    loadImageUrls();
  }, [properties]);

  const loadImageUrls = async () => {
    const urls: Record<string, string> = {};
    
    for (const property of properties) {
      if (property.property_images && property.property_images.length > 0) {
        const primaryImage = property.property_images.find((img: any) => img.is_primary) || 
                           property.property_images[0];
        
        try {
          const { data } = await supabase.storage
            .from('property-images')
            .createSignedUrl(primaryImage.image_url, 3600);
          
          if (data) {
            urls[property.id] = data.signedUrl;
          }
        } catch (error) {
          console.error('Error loading image:', error);
        }
      }
    }
    
    setImageUrls(urls);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-success text-success-foreground"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge className="bg-pending text-pending-foreground"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    }
  };

  if (properties.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12">
          <div className="text-center space-y-2">
            <h3 className="text-lg font-semibold text-muted-foreground">No properties found</h3>
            <p className="text-sm text-muted-foreground">
              {isAdmin ? 'No properties pending review' : 'Start by adding your first property'}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {properties.map((property) => (
        <Card key={property.id} className="overflow-hidden">
          {imageUrls[property.id] && (
            <div className="aspect-video overflow-hidden">
              <img
                src={imageUrls[property.id]}
                alt={property.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}
          
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <CardTitle className="text-lg leading-tight">{property.title}</CardTitle>
              {showStatus && getStatusBadge(property.status)}
            </div>
          </CardHeader>
          
          <CardContent className="space-y-3">
            <div className="flex items-center text-muted-foreground text-sm">
              <MapPin className="h-4 w-4 mr-1" />
              {property.location}
            </div>
            
            <div className="flex items-center text-lg font-semibold text-primary">
              <DollarSign className="h-5 w-5 mr-1" />
              {property.price.toLocaleString('en-GH')} GHS/month
            </div>
            
            <p className="text-sm text-muted-foreground line-clamp-2">
              {property.description}
            </p>
            
            {property.admin_notes && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-xs"><strong>Admin Notes:</strong> {property.admin_notes}</p>
              </div>
            )}
            
            <div className="text-xs text-muted-foreground">
              Listed on {new Date(property.created_at).toLocaleDateString()}
            </div>

            {isAdmin && (
              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  onClick={() => onApprove?.(property.id)}
                  disabled={property.status === 'approved'}
                  className="flex-1"
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Approve
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  onClick={() => onReject?.(property.id, '')}
                  disabled={property.status === 'rejected'}
                  className="flex-1"
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}