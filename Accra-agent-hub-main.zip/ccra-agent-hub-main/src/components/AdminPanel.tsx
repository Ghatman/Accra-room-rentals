import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { Users, Home, CheckCircle, XCircle, Clock, Eye, FileText } from 'lucide-react';
import { PropertyList } from './PropertyList';

interface LandlordProfile {
  id: string;
  user_id: string;
  full_name: string;
  phone: string;
  ghana_card_url: string;
  ghana_card_status: string;
  verification_notes?: string;
  created_at: string;
}

interface Property {
  id: string;
  title: string;
  status: string;
  landlord_id: string;
  price: number;
  location: string;
  description: string;
  admin_notes?: string;
  created_at: string;
  profiles?: {
    full_name: string;
  };
  property_images?: Array<{
    id: string;
    image_url: string;
    is_primary: boolean;
  }>;
}

export function AdminPanel() {
  const [landlords, setLandlords] = useState<LandlordProfile[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLandlord, setSelectedLandlord] = useState<LandlordProfile | null>(null);
  const [verificationNotes, setVerificationNotes] = useState('');
  const [ghanaCardUrl, setGhanaCardUrl] = useState<string | null>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch landlords
      const { data: landlordsData, error: landlordsError } = await supabase
        .from('profiles')
        .select(`
          *,
          user_roles!inner(role)
        `)
        .eq('user_roles.role', 'landlord')
        .order('created_at', { ascending: false });

      if (landlordsError) throw landlordsError;

      // Fetch properties with landlord info
      const { data: propertiesData, error: propertiesError } = await supabase
        .from('properties')
        .select(`
          *,
          profiles!properties_landlord_id_fkey(full_name),
          property_images(*)
        `)
        .order('created_at', { ascending: false });

      if (propertiesError) throw propertiesError;

      setLandlords(landlordsData || []);
      setProperties((propertiesData || []) as unknown as Property[]);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const viewGhanaCard = async (landlord: LandlordProfile) => {
    setSelectedLandlord(landlord);
    setVerificationNotes(landlord.verification_notes || '');
    
    if (landlord.ghana_card_url) {
      try {
        const { data } = await supabase.storage
          .from('ghana-cards')
          .createSignedUrl(landlord.ghana_card_url, 3600);
        
        setGhanaCardUrl(data?.signedUrl || null);
      } catch (error) {
        console.error('Error loading Ghana card:', error);
      }
    }
  };

  const updateLandlordStatus = async (status: 'approved' | 'rejected') => {
    if (!selectedLandlord) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          ghana_card_status: status,
          verification_notes: verificationNotes,
        })
        .eq('user_id', selectedLandlord.user_id);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Landlord ${status} successfully`,
      });

      setSelectedLandlord(null);
      setVerificationNotes('');
      setGhanaCardUrl(null);
      fetchData();
    } catch (error) {
      console.error('Error updating landlord:', error);
      toast({
        title: "Error",
        description: "Failed to update landlord status",
        variant: "destructive",
      });
    }
  };

  const handlePropertyAction = async (propertyId: string, action: 'approve' | 'reject', notes: string = '') => {
    try {
      const { error } = await supabase
        .from('properties')
        .update({
          status: action === 'approve' ? 'approved' : 'rejected',
          admin_notes: notes,
        })
        .eq('id', propertyId);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Property ${action}d successfully`,
      });

      fetchData();
    } catch (error) {
      console.error('Error updating property:', error);
      toast({
        title: "Error",
        description: "Failed to update property",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-success text-success-foreground"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge className="bg-pending text-pending-foreground"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    }
  };

  const getStats = () => {
    const pendingLandlords = landlords.filter(l => l.ghana_card_status === 'pending').length;
    const pendingProperties = properties.filter(p => p.status === 'pending').length;
    const approvedProperties = properties.filter(p => p.status === 'approved').length;
    
    return { pendingLandlords, pendingProperties, approvedProperties };
  };

  const stats = getStats();

  if (loading) {
    return (
      <div className="flex justify-center py-8">
        <div className="animate-spin h-8 w-8 border-2 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Verifications</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingLandlords}</div>
            <p className="text-xs text-muted-foreground">Landlords awaiting verification</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Properties</CardTitle>
            <Home className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pendingProperties}</div>
            <p className="text-xs text-muted-foreground">Properties awaiting approval</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Live Properties</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.approvedProperties}</div>
            <p className="text-xs text-muted-foreground">Published properties</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="landlords" className="space-y-4">
        <TabsList>
          <TabsTrigger value="landlords">
            Landlord Verification ({stats.pendingLandlords})
          </TabsTrigger>
          <TabsTrigger value="properties">
            Property Review ({stats.pendingProperties})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="landlords">
          <Card>
            <CardHeader>
              <CardTitle>Landlord Verification</CardTitle>
              <CardDescription>
                Review and verify landlord Ghana Card submissions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {landlords.map((landlord) => (
                  <div key={landlord.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="space-y-1">
                      <h4 className="font-semibold">{landlord.full_name}</h4>
                      <p className="text-sm text-muted-foreground">{landlord.phone}</p>
                      <p className="text-xs text-muted-foreground">
                        Registered: {new Date(landlord.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(landlord.ghana_card_status)}
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => viewGhanaCard(landlord)}
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        Review
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="properties">
          <Card>
            <CardHeader>
              <CardTitle>Property Review</CardTitle>
              <CardDescription>
                Review and approve property listings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <PropertyList
                properties={properties}
                onUpdate={fetchData}
                showStatus={true}
                isAdmin={true}
                onApprove={(propertyId) => handlePropertyAction(propertyId, 'approve')}
                onReject={(propertyId) => {
                  const notes = prompt('Enter rejection reason:');
                  if (notes) {
                    handlePropertyAction(propertyId, 'reject', notes);
                  }
                }}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Ghana Card Review Modal */}
      {selectedLandlord && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-background rounded-lg max-w-4xl w-full max-h-[90vh] overflow-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold">Verify Landlord: {selectedLandlord.full_name}</h3>
                <Button variant="ghost" onClick={() => {
                  setSelectedLandlord(null);
                  setGhanaCardUrl(null);
                  setVerificationNotes('');
                }}>
                  ×
                </Button>
              </div>

              <div className="space-y-6">
                {/* Ghana Card Image */}
                {ghanaCardUrl && (
                  <div className="space-y-2">
                    <Label>Ghana Card</Label>
                    <div className="border rounded-lg overflow-hidden">
                      <img
                        src={ghanaCardUrl}
                        alt="Ghana Card"
                        className="w-full max-h-96 object-contain"
                      />
                    </div>
                  </div>
                )}

                {/* Verification Notes */}
                <div className="space-y-2">
                  <Label htmlFor="notes">Verification Notes</Label>
                  <Textarea
                    id="notes"
                    value={verificationNotes}
                    onChange={(e) => setVerificationNotes(e.target.value)}
                    placeholder="Add notes about the verification process..."
                    rows={3}
                  />
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    onClick={() => updateLandlordStatus('approved')}
                    className="flex-1"
                    disabled={selectedLandlord.ghana_card_status === 'approved'}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Approve
                  </Button>
                  <Button
                    variant="destructive"
                    onClick={() => updateLandlordStatus('rejected')}
                    className="flex-1"
                    disabled={selectedLandlord.ghana_card_status === 'rejected'}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Reject
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}