import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileUpload } from '@/components/FileUpload';
import { toast } from '@/components/ui/use-toast';
import { MapPin, DollarSign, FileText, Camera } from 'lucide-react';

interface PropertyFormProps {
  onSuccess?: () => void;
}

export function PropertyForm({ onSuccess }: PropertyFormProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [location, setLocation] = useState('');
  const [propertyImages, setPropertyImages] = useState<File[]>([]);
  const [tenancyAgreement, setTenancyAgreement] = useState<File | null>(null);
  const [ownershipPapers, setOwnershipPapers] = useState<File | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to add properties",
        variant: "destructive",
      });
      return;
    }
    
    if (propertyImages.length === 0) {
      toast({
        title: "Error",
        description: "Please upload at least one property image",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      // Create property record
      const { data: property, error: propertyError } = await supabase
        .from('properties')
        .insert({
          landlord_id: user.id,
          title,
          description,
          price: parseFloat(price),
          location,
        })
        .select()
        .single();

      if (propertyError) throw propertyError;

      // Upload property images
      const imageUploadPromises = propertyImages.map(async (file, index) => {
        const fileExt = file.name.split('.').pop();
        const fileName = `${user.id}/${property.id}/image-${index}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('property-images')
          .upload(fileName, file);

        if (uploadError) throw uploadError;

        // Save image record
        const { error: imageError } = await supabase
          .from('property_images')
          .insert({
            property_id: property.id,
            image_url: fileName,
            is_primary: index === 0,
          });

        if (imageError) throw imageError;
      });

      await Promise.all(imageUploadPromises);

      // Upload documents
      let tenancyUrl = null;
      let ownershipUrl = null;

      if (tenancyAgreement) {
        const fileExt = tenancyAgreement.name.split('.').pop();
        const fileName = `${user.id}/${property.id}/tenancy-agreement.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('property-documents')
          .upload(fileName, tenancyAgreement);

        if (uploadError) throw uploadError;
        tenancyUrl = fileName;
      }

      if (ownershipPapers) {
        const fileExt = ownershipPapers.name.split('.').pop();
        const fileName = `${user.id}/${property.id}/ownership-papers.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('property-documents')
          .upload(fileName, ownershipPapers);

        if (uploadError) throw uploadError;
        ownershipUrl = fileName;
      }

      // Update property with document URLs
      if (tenancyUrl || ownershipUrl) {
        const { error: updateError } = await supabase
          .from('properties')
          .update({
            tenancy_agreement_url: tenancyUrl,
            ownership_papers_url: ownershipUrl,
          })
          .eq('id', property.id);

        if (updateError) throw updateError;
      }

      toast({
        title: "Success",
        description: "Property added successfully! It will be reviewed by admin.",
      });

      // Reset form
      setTitle('');
      setDescription('');
      setPrice('');
      setLocation('');
      setPropertyImages([]);
      setTenancyAgreement(null);
      setOwnershipPapers(null);

      onSuccess?.();
    } catch (error) {
      console.error('Error adding property:', error);
      toast({
        title: "Error",
        description: "Failed to add property. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Property</CardTitle>
        <CardDescription>
          Fill in the details below to list your property for review
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Basic Information
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Property Title</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                  placeholder="e.g., Modern 3-bedroom Apartment"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Monthly Rent (GHS)</Label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="price"
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                    placeholder="1500"
                    className="pl-10"
                    min="0"
                    step="0.01"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="location">Location (Accra)</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="location"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  required
                  placeholder="e.g., East Legon, Accra"
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
                placeholder="Describe your property, amenities, nearby facilities, etc."
                rows={4}
              />
            </div>
          </div>

          {/* Property Images */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <Camera className="h-5 w-5" />
              Property Images
            </h3>
            
            <FileUpload
              label="Property Images"
              accept="image/*"
              onChange={() => {}} // Not used when multiple=true
              multiple
              files={propertyImages}
              onMultipleChange={setPropertyImages}
              description="Upload high-quality images of your property (interior, exterior, amenities)"
              maxSize={10}
            />
          </div>

          {/* Documents */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Property Documents
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FileUpload
                label="Tenancy Agreement"
                accept=".pdf,.doc,.docx,image/*"
                onChange={setTenancyAgreement}
                description="Upload sample tenancy agreement (PDF preferred)"
              />

              <FileUpload
                label="Property Ownership Papers"
                accept=".pdf,.doc,.docx,image/*"
                onChange={setOwnershipPapers}
                description="Upload proof of property ownership"
              />
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading ? 'Adding Property...' : 'Add Property'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}