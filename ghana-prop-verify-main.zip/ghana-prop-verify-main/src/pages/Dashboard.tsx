import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import ProtectedRoute from '@/components/ProtectedRoute';

const Dashboard = () => {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchProfile();
  }, []);

  const fetchProfile = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('user_id', session.user.id)
          .single();

        if (error) {
          console.error('Error fetching profile:', error);
        } else {
          setProfile(data);
        }
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Success",
        description: "Logged out successfully",
      });
      navigate('/');
    } catch (error) {
      toast({
        title: "Error",
        description: "Error signing out",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <ProtectedRoute requireGhanaCard>
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/10">
        <div className="container mx-auto p-6">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-primary">Landlord Dashboard</h1>
              <p className="text-muted-foreground">Welcome to E-agent</p>
            </div>
            <Button onClick={handleSignOut} variant="outline">
              Sign Out
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Profile Status</CardTitle>
                <CardDescription>Your account verification status</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Email:</span>
                    <span className="font-medium">{profile?.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Role:</span>
                    <Badge variant="secondary">{profile?.role}</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Ghana Card:</span>
                    {profile?.ghana_card_verified ? (
                      <Badge className="bg-success text-success-foreground">Verified</Badge>
                    ) : (
                      <Badge variant="destructive">Pending</Badge>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Properties</CardTitle>
                <CardDescription>Manage your rental properties</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">No properties added yet.</p>
                <Button className="w-full" disabled>
                  Add Property (Coming Soon)
                </Button>
              </CardContent>
            </Card>

            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Tenants</CardTitle>
                <CardDescription>Manage your tenants</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">No tenants found.</p>
                <Button className="w-full" disabled>
                  Add Tenant (Coming Soon)
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </ProtectedRoute>
  );
};

export default Dashboard;