import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import ProtectedRoute from '@/components/ProtectedRoute';

const AdminDashboard = () => {
  const [landlords, setLandlords] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    fetchLandlords();
  }, []);

  const fetchLandlords = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'landlord')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching landlords:', error);
      } else {
        setLandlords(data || []);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyLandlord = async (landlordId: string, verify: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ ghana_card_verified: verify })
        .eq('id', landlordId);

      if (error) {
        toast({
          title: "Error",
          description: "Failed to update verification status",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Success",
          description: `Landlord ${verify ? 'verified' : 'rejected'} successfully`,
        });
        fetchLandlords(); // Refresh the list
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive",
      });
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Success",
        description: "Logged out successfully",
      });
      navigate('/');
    } catch (error) {
      toast({
        title: "Error",
        description: "Error signing out",
        variant: "destructive",
      });
    }
  };

  const viewGhanaCard = (url: string) => {
    if (url) {
      window.open(url, '_blank');
    } else {
      toast({
        title: "No Ghana Card",
        description: "This landlord hasn't uploaded their Ghana Card yet",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  }

  return (
    <ProtectedRoute requireAdmin>
      <div className="min-h-screen bg-gradient-to-br from-primary/5 to-accent/10">
        <div className="container mx-auto p-6">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-primary">Admin Dashboard</h1>
              <p className="text-muted-foreground">Manage landlord verifications</p>
            </div>
            <Button onClick={handleSignOut} variant="outline">
              Sign Out
            </Button>
          </div>

          <Card className="shadow-card">
            <CardHeader>
              <CardTitle>Registered Landlords</CardTitle>
              <CardDescription>
                Manage landlord accounts and Ghana Card verifications
              </CardDescription>
            </CardHeader>
            <CardContent>
              {landlords.length === 0 ? (
                <p className="text-muted-foreground text-center py-8">
                  No landlords registered yet.
                </p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Email</TableHead>
                      <TableHead>Registration Date</TableHead>
                      <TableHead>Ghana Card</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {landlords.map((landlord) => (
                      <TableRow key={landlord.id}>
                        <TableCell className="font-medium">{landlord.email}</TableCell>
                        <TableCell>
                          {new Date(landlord.created_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          {landlord.ghana_card_url ? (
                            <Button 
                              variant="link" 
                              size="sm"
                              onClick={() => viewGhanaCard(landlord.ghana_card_url)}
                            >
                              View Card
                            </Button>
                          ) : (
                            <span className="text-muted-foreground">Not uploaded</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {landlord.ghana_card_verified ? (
                            <Badge className="bg-success text-success-foreground">Verified</Badge>
                          ) : landlord.ghana_card_url ? (
                            <Badge className="bg-warning text-warning-foreground">Pending Review</Badge>
                          ) : (
                            <Badge variant="secondary">Awaiting Upload</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {landlord.ghana_card_url && !landlord.ghana_card_verified && (
                              <>
                                <Button
                                  size="sm"
                                  onClick={() => handleVerifyLandlord(landlord.id, true)}
                                  className="bg-success hover:bg-success/90"
                                >
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => handleVerifyLandlord(landlord.id, false)}
                                >
                                  Reject
                                </Button>
                              </>
                            )}
                            {landlord.ghana_card_verified && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleVerifyLandlord(landlord.id, false)}
                              >
                                Revoke
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </ProtectedRoute>
  );
};

export default AdminDashboard;